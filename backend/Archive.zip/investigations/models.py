from datetime import datetime, timezone

from sqlalchemy import (
    String,
    Text,
    DateTime,
    ForeignKey
)

from sqlalchemy.orm import Mapped, mapped_column

from database.base import Base


class Investigation(Base):

    __tablename__ = "investigations"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True
    )

    break_id: Mapped[str] = mapped_column(
        ForeignKey("breaks.id")
    )

    investigator_id: Mapped[str] = mapped_column(
        ForeignKey("users.id")
    )

    justification: Mapped[str] = mapped_column(
        Text
    )

    status: Mapped[str] = mapped_column(
        String(30),
        default="SUBMITTED"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc)
    )