from pydantic import BaseModel


class UserOut(BaseModel):

    id: str
    username: str
    role: str
    is_active: bool

    class Config:
        from_attributes = True