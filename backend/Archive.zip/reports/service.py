from reports.pdf_generator import generate_pdf
from reports.excel_generator import generate_excel


def create_pdf_report(
    workflow_name,
    period,
    breaks
):

    lines = [
        f"Workflow: {workflow_name}",
        f"Period: {period}",
        f"Total Breaks: {len(breaks)}"
    ]

    for item in breaks:

        lines.append(
            f"Break {item.id}: "
            f"{item.status}"
        )

    return generate_pdf(
        "OneRecon Reconciliation Report",
        lines
    )


def create_excel_report(
    breaks
):

    rows = []

    for item in breaks:

        rows.append({
            "Break ID": item.id,
            "Status": item.status,
            "Field": item.field,
            "Expected": item.expected_value,
            "Actual": item.actual_value,
            "Difference": item.difference
        })

    return generate_excel(rows)