from pydantic import BaseModel


class LoginRequest(BaseModel):

    username: str
    password: str


class LoginResponse(BaseModel):

    user_id: str
    username: str
    role: str
    token: str
    token_type: str = "bearer"


class RegisterRequest(BaseModel):

    full_name: str
    email: str
    password: str
    role: str = "INVESTIGATOR"


class RegisterResponse(BaseModel):

    user_id: str
    username: str
    role: str


class UserResponse(BaseModel):

    id: str
    username: str
    email: str | None = None
    full_name: str | None = None
    role: str
    is_active: bool

    class Config:
        from_attributes = True