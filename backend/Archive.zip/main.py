from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config.settings import settings

from database.base import (
    Base,
    engine
)

# Import models so SQLAlchemy registers them
import database.models

# Routers
from auth.router import router as auth_router
from users.router import router as users_router
from workflows.router import router as workflows_router
from investigations.router import router as investigations_router
from approvals.router import router as approvals_router
from audit.router import router as audit_router
from reports.router import router as reports_router
from breaks.router import router as breaks_router
from admin.router import router as admin_router
from data_sources.router import router as data_sources_router
from field_mappings.router import router as field_mappings_router
from ingestion.router import router as ingestion_router
from ai_bridge.router import router as ai_bridge_router


app = FastAPI(
    title="OneRecon Backend",
    description="Financial reconciliation backend",
    version="1.0.0"
)


# ============================================================
# REACT FRONTEND CONNECTION
# ============================================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=settings.frontend_origins,

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


# ============================================================
# DATABASE
# ============================================================

@app.on_event("startup")
def startup():

    try:

        Base.metadata.create_all(
            bind=engine
        )

        _seed_demo_users()

    except Exception as error:

        print(
            "Database startup failed:"
            f" {type(error).__name__}: {error}"
        )
        print(
            "Backend is running, but "
            "database-backed APIs will fail."
        )


# ============================================================
# ROUTERS
# ============================================================

app.include_router(
    auth_router,
    prefix="/api"
)

app.include_router(
    users_router,
    prefix="/api"
)

app.include_router(
    workflows_router,
    prefix="/api"
)

app.include_router(
    investigations_router,
    prefix="/api"
)

app.include_router(
    approvals_router,
    prefix="/api"
)

app.include_router(
    audit_router,
    prefix="/api"
)

app.include_router(
    reports_router,
    prefix="/api"
)

app.include_router(
    breaks_router,
    prefix="/api"
)

app.include_router(
    admin_router,
    prefix="/api"
)

app.include_router(
    data_sources_router,
    prefix="/api"
)

app.include_router(
    field_mappings_router,
    prefix="/api"
)

app.include_router(
    ingestion_router,
    prefix="/api"
)

app.include_router(
    ai_bridge_router,
    prefix="/api"
)


# ============================================================
# HEALTH
# ============================================================

@app.get("/")
def root():

    return {
        "message": "OneRecon Backend",
        "status": "running"
    }


@app.get("/health")
def health():

    return {
        "status": "ok",
        "service": "onerecon-backend"
    }


def _seed_demo_users():

    from sqlalchemy.orm import Session

    from users.models import User
    from auth.security import hash_password

    session = Session(
        bind=engine
    )

    demo_users = [
        (
            "admin@onerecon.com",
            "Admin@123",
            "ADMIN"
        ),
        (
            "investigator@onerecon.com",
            "Investigator@123",
            "INVESTIGATOR"
        ),
        (
            "approver@onerecon.com",
            "Approver@123",
            "APPROVER"
        ),
    ]

    try:

        for email, password, role in demo_users:

            existing = (
                session.query(User)
                .filter(
                    (User.username == email)
                    | (User.email == email)
                )
                .first()
            )

            if existing:

                continue

            session.add(
                User(
                    id=str(__import__("uuid").uuid4()),
                    username=email,
                    email=email,
                    full_name=f"Demo {role.title()}",
                    password_hash=hash_password(password),
                    role=role,
                    is_active=True
                )
            )

        session.commit()

    finally:

        session.close()